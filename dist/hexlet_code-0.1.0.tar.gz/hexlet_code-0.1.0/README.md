### Hexlet tests and linter status:
[![Actions Status](https://github.com/HugoTheDeveloper/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/HugoTheDeveloper/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/a509bf44f2f2f959032e/maintainability)](https://codeclimate.com/github/HugoTheDeveloper/python-project-49/maintainability)
[Brain-even demo here   ](https://asciinema.org/a/ayMkb8tXOKj9M5Yym101dEIVr)
[Brain-calc demo here   ](https://asciinema.org/a/8hjf37uukVlMzZxtFB4ihwzdh)
[Brain-gcd demo here   ](https://asciinema.org/a/TDgeJyNRfK9KGy39kheTo16Pl)
