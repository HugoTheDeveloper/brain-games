### Hexlet tests and linter status:
[![Actions Status](https://github.com/HugoTheDeveloper/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/HugoTheDeveloper/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/a509bf44f2f2f959032e/maintainability)](https://codeclimate.com/github/HugoTheDeveloper/python-project-49/maintainability)